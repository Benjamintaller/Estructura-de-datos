#include "stdafx.h"
#include "Paralelogramo.h"

Paralelogramo::Paralelogramo(void)
{
    base = 0;
    altura = 0;
}

void Paralelogramo::setalura(int a)
{
    altura = a; // Asigna el argumento al atributo de la clase
}

void Paralelogramo::setbase(int b)
{
    base = b; // Asigna el argumento al atributo de la clase
}

int Paralelogramo::getaltura()
{
    return altura;
}

int Paralelogramo::getbase()
{
    return base;
}
int Paralelogramo::getArea()
{
    return base * altura; // Usa los atributos internos de la clase
}

Paralelogramo::~Paralelogramo(void)
{
}
