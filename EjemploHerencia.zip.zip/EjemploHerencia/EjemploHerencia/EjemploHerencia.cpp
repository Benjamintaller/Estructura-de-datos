// EjemploHerencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "conio.h"
#include "Paralelogramo.h"
using namespace std;

int main(void) {
   Rectangulo Rect;
   Paralelogramo * juls=new Paralelogramo();
   int base, altura;
   Rect.setWidth(5);
   Rect.setHeight(7);
   
   cout << "ingrese la base del paralelogramo: ";
   cin >> base;
   cout << "ingrese la altura del paralelogramo: ";
   cin >> altura;
   juls->setbase(base);
   juls->setalura(altura);
   // Muestra el �rea de un rectangulo
   cout << "Total area: " << Rect.getArea() << endl;
   cout << "Total area paralelogramo: " << juls->getArea( ) << endl;
   return 0;
}