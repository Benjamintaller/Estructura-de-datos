#pragma once
#include "Shape.h"
class Paralelogramo: public Shape{
private:
	int base, altura;
public:
	Paralelogramo(void);
	void setalura(int a);
	void setbase(int b);
	~Paralelogramo(void);
	
	int getaltura();
	int getbase();
	int getArea();
	
};

